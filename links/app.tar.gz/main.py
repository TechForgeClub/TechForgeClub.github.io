import flet as ft

def main(page:ft.Page):
    
    #page.dark_theme = ft.Theme(color_scheme_seed="black")
    page.theme_mode=ft.ThemeMode.DARK
    
    def gotopwn(e):
        page.launch_url("https://haveibeenpwned.com/")
        
    def gotohackthebox(e):
        page.launch_url("https://referral.hackthebox.com/mz5r7im")
        
    def goto_coursera(e):
        page.launch_url("https://learn.mindmatrix.io/users/sign_up")
        
    def open_techforge(e):
        page.launch_url("https://techforge.jnnce.ac.in/")    
        
    page.appbar = ft.AppBar(
        leading=ft.Image(src='TechForge-logos_black-modified.png',width=30,height=30,border_radius=100),
        leading_width=50,
        title=ft.Text("Techforge"),
        center_title=False,
        bgcolor=ft.colors.BLUE_ACCENT_400,
        actions=[
            
            ft.PopupMenuButton(
                items=[
                    ft.PopupMenuItem(text='Link',on_click=open_techforge),
                   
                    
                ]
            ),
        ],
    )    
    pwned=ft.ElevatedButton(content=ft.Text("Have u been pwned",size=20),on_click=gotopwn,width=300,height=100,color=ft.colors.BLUE_300,)
    hackthebox=ft.ElevatedButton(content=ft.Text("hack the box",size=20),on_click=gotohackthebox,width=300,height=100,color=ft.colors.BLUE_300,)
    coursera=ft.ElevatedButton(content=ft.Text("Cybersecurity courses",size=20),on_click=goto_coursera,width=300,height=100,color=ft.colors.BLUE_300)
    
    view = ft.Column(
        
    
        controls=[
            ft.Row(
                controls=[
                  pwned
                ],
                   
                alignment=ft.MainAxisAlignment.CENTER,
            ),
            ft.Row(),
            ft.Row(
                controls=[
                  hackthebox
                ],
                   
                alignment=ft.MainAxisAlignment.CENTER,
            ),
            ft.Row(),
            ft.Row(
                controls=[
                  coursera
                ],     
                alignment=ft.MainAxisAlignment.CENTER,
            ),
        ],
        alignment=ft.MainAxisAlignment.CENTER,
    )
    
    page.vertical_alignment=ft.MainAxisAlignment.CENTER
    page.horizontal_alignment=ft.CrossAxisAlignment.CENTER
    
    page.add(view)
ft.app(target=main,view=ft.WEB_BROWSER,assets_dir="assets")


  